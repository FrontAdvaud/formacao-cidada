<?php

header("Location: https://portal.aprofem.com.br");

?>